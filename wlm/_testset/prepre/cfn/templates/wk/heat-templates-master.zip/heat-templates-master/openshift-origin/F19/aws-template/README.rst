=============================
OpenShift Origin AWS Template
=============================

This directory contains template for deploying OpenShift Origin to an OpenStack environment via Heat.

It includes the following file:

* `openshift.template` - heat templates in AWS format for launching OpenShift Origin with a single broker instance and a single node instance

