A hook which invokes ``puppet apply`` on the provided configuration.
Config inputs are passed in as facts, and output values are read from written-out
files.