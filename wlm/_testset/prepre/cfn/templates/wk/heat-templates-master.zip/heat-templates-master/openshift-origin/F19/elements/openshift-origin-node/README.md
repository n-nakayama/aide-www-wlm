Minimal packages required for Heat to successfully
deploy an OpenShift Origin Node instance.

Note: All other packages are managed by Puppet.
