========================================
Example software configuration templates
========================================

These example templates demonstrate various aspects of using Heat's
software configuration templates. The description in each template describes what
that template demonstrates.

See heat-templates/hot/software-config/elements/README.rst for instructions on
building an image which works with these templates.