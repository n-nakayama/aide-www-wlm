Minimal packages required for Heat to successfully
deploy an OpenShift Origin Broker instance.

Note: All other packages are managed by Puppet.
